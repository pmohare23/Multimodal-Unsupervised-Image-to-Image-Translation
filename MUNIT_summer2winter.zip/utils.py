import glob
import os
import numpy as np

import matplotlib.pyplot as plt
import csv

from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms

from torch.autograd import Variable
from torchvision.utils import save_image
import torch

class ImageDataset(Dataset):
    def __init__(self, root, transforms_=None, mode="train"):
        self.transform = transforms.Compose(transforms_)

        # due to difference in file organization of this database which A and B are seperate:
        if mode == "train":
            mode = "summer/summer"
            self.files_A = sorted(glob.glob(os.path.join(root, mode) + "/*.*"))
            mode = "winter/winter"
            self.files_B = sorted(glob.glob(os.path.join(root, mode) + "/*.*"))
        elif mode == "val":
            mode = "test_summer/summer"
            self.files_A = sorted(glob.glob(os.path.join(root, mode) + "/*.*"))
            mode = "test_winter/winter"
            self.files_B = sorted(glob.glob(os.path.join(root, mode) + "/*.*"))
        else:
            self.files = sorted(glob.glob("test/*.*"))

    def __getitem__(self, index):

    
        try:
            img_A = Image.open(self.files_A[index % len(self.files_A)])
            img_B = Image.open(self.files_B[index % len(self.files_B)])
        except: 
            img = Image.open(self.files[index % len(self.files)])
            img = Image.fromarray(np.array(img)[:, ::-1, :], "RGB")
            img = self.transform(img)
            return {"A": img,"B":self.files[index % len(self.files)]}
            #w, h = img.size
            # img_A = img.crop((0, 0, w / 2, h))
            # img_B = img.crop((w / 2, 0, w, h))

        if np.random.random() < 0.5:
            img_A = Image.fromarray(np.array(img_A)[:, ::-1, :], "RGB")
            img_B = Image.fromarray(np.array(img_B)[:, ::-1, :], "RGB")

        img_A = self.transform(img_A)
        img_B = self.transform(img_B)

        return {"A": img_A, "B": img_B}

    def __len__(self):
        try:
            length = min (len(self.files_A), len(self.files_B))
        except:
            length = len(self.files)
        return length


def sample_images(batches_done, lambdas, val_dataloader, opt, Tensor, Enc1, Dec2):
    """Saves a generated sample from the validation set"""
    imgs = next(iter(val_dataloader))
    img_samples = None
    lambdas_name = ("%s_%s_%s_%s_%s" % lambdas)
    for img1, img2 in zip(imgs["A"], imgs["B"]):
        # Create copies of image
        X1 = img1.unsqueeze(0).repeat(opt.style_dim, 1, 1, 1)
        X1 = Variable(X1.type(Tensor))
        # Get random style codes
        s_code = np.random.uniform(-1, 1, (opt.style_dim, opt.style_dim))
        s_code = Variable(Tensor(s_code))
        # Generate samples
        c_code_1, _ = Enc1(X1)
        X12 = Dec2(c_code_1, s_code)
        # Concatenate samples horisontally
        X12 = torch.cat([x for x in X12.data.cpu()], -1)
        img_sample = torch.cat((img1, X12), -1).unsqueeze(0)
        # Concatenate with previous samples vertically
        img_samples = img_sample if img_samples is None else torch.cat((img_samples, img_sample), -2)
    save_image(img_samples, "images/%s/B %s-W %s.png" % (opt.dataset_name, batches_done, lambdas_name), nrow=5, normalize=True)
    
    
def loss_output(G_losses, D_losses, epoch, opt, lambdas):
    lambdas_name = ("%s_%s_%s_%s_%s" % lambdas)
    try:
        plt.figure()
        plt.title('Generator and Discriminator loss During Training || epochs=%s' %epoch)
        plt.plot(G_losses, label = 'G')
        plt.plot(D_losses, label = 'D')
        plt.xlabel('epochs')
        plt.ylabel('Loss')
        plt.legend()
        #plt.show()
        plt.savefig("loss_output/%s/losses-W %s.png" % (opt.dataset_name, lambdas_name))
    except:
        print("plot file is open!!", "===> epoch = %s" %epoch)
    try:
        file = open('loss_output/%s/losses-W %s.csv' % (opt.dataset_name, lambdas_name), 'w')
        writer = csv.writer(file)
        writer.writerow(list(range(0,epoch+1)))
        writer.writerow(G_losses)
        writer.writerow(D_losses)
        file.close()
    except:
        print("CSV file is open!!", "===> epoch = %s" %epoch)

